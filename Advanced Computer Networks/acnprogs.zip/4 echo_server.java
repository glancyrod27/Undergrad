import java.io.*;
import java.net.*;
class server
{
     public static void main(String arg[])throws IOException
     {
          ServerSocket server=new ServerSocket(2500);
          Socket sock;
          System.out.println("server starting....");
          sock=server.accept();
          BufferedReader datain=new BufferedReader(new InputStreamReader(sock.getInputStream()));
          System.out.println("Accepted");
          System.out.println(datain.readLine());
          sock.close();
          server.close();

     }

}

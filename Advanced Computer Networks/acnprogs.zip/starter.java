import java.io.*;

public class starter
 {
    static Integer listen_port = null;

   public static void main(String[] args) 
    {
    
    try 
    {
      listen_port = new Integer(args[0]);
      
    }
    catch (Exception e) 
    {
      listen_port = new Integer(80);
    }
    
    starter webserver = new starter();
    server2 s1=new server2(listen_port.intValue(), webserver);
  }
 
   public void send_message_to_window(String s)
  {
    System.out.println(s);
  }
} 

import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.util.Date;

public class server1 extends Thread 
{
	
  private starter message_to; 
  private int port; 
	 public server1(int listen_port, starter to_send_message_to) 
	{
  	  message_to = to_send_message_to;
 	   port = listen_port;
  	  this.start();
	  }


  private void s(String s2)
 { 
    message_to.send_message_to_window(s2);
  }


  public void run() 
	{
    ServerSocket serversocket = null;
     s("Apoorv's httpserver \n\n");
    
    try 
	{
     
      s("Trying to bind to localhost on port " + Integer.toString(port) + "...");
          serversocket = new ServerSocket(port);
   	 }

    catch (Exception e) 
	{ 
      s("\nFatal Error:" + e.getMessage());
      return;
    	}
    s("OK!\n");
    
    while (true) 
    {
      s("\nReady, Waiting for requests...\n");
      try 
	{
       
        Socket connectionsocket = serversocket.accept();
      
        InetAddress client = connectionsocket.getInetAddress();
        s(client.getHostName() + " connected to server.\n");
        
        BufferedReader input =new BufferedReader(new InputStreamReader(connectionsocket.getInputStream()));
        DataOutputStream output =new DataOutputStream(connectionsocket.getOutputStream());

        http_handler(input, output);
    	}
      
	catch (Exception e)
	 { 
        s("\nError:" + e.getMessage());
         }

    } 
  }

    private void http_handler(BufferedReader input, DataOutputStream output)
    {
    int method = 0; 
    String http = new String(); 
    String path = new String(); 
    String file = new String();
    String user_agent = new String(); 
    try 
	{
      
      String tmp = input.readLine();
      String tmp2 = new String(tmp);
      tmp.toUpperCase(); 
      if (tmp.startsWith("GET")) 
	{ 
        method = 1;
      }
      if (tmp.startsWith("HEAD"))
	 { 
        method = 2;
      } 

      if (method == 0)
      { 
        try 
	{
          output.writeBytes(construct_http_header(501, 0));
          output.close();
          return;
        }
        catch (Exception e3) 
	{ 
          s("error:" + e3.getMessage());
        } 
      }
     
      int start = 0;
      int end = 0;
      for (int a = 0; a < tmp2.length(); a++) 
	{
        if (tmp2.charAt(a) == ' ' && start != 0)
	 {
          end = a;
          break;
        }
        if (tmp2.charAt(a) == ' ' && start == 0)
	 {
          start = a;
        }
      }
      path = tmp2.substring(start + 2, end); 
    }
    catch (Exception e) 
	{
      s("errorr" + e.getMessage());
   } 

     s("\nClient requested:" + new File(path).getAbsolutePath() + "\n");
    FileInputStream requestedfile = null;

    try 
	{
     
      requestedfile = new FileInputStream(path);
    }
    catch (Exception e)
    {
      try
      {
         output.writeBytes(construct_http_header(404, 0));
         output.close();
      }
      catch (Exception e2)
	 {}
      s("error" + e.getMessage());
    } 

    try 
	{
      int type_is = 0;
      
      if (path.endsWith(".zip") )
      {
        type_is = 3;
      }
      if (path.endsWith(".jpg") || path.endsWith(".jpeg"))
      {
        type_is = 1;
      }
      if (path.endsWith(".gif"))
      {
        type_is = 2;      
      }
      if (path.endsWith(".ico")) 
      {
        type_is = 4;
      }
	if (path.endsWith(".html")) 
      {
        type_is = 5;
      }

	
      
      output.writeBytes(construct_http_header(200, type_is));
   
      if (method == 1) 
      { 
    	byte [] buffer = new byte[1024];
        while (true)
        {
         
          int b = requestedfile.read(buffer, 0,1024);
          if (b == -1)
          {
            break; 
          }
          output.write(buffer,0,b);
        }
                
      }
      output.close();
      requestedfile.close();
    }

    catch (Exception e)
    {}

  }

  private String construct_http_header(int return_code, int file_type)
 {
    String s = "HTTP/1.0 ";
   
    switch (return_code) 
	{
      case 200:
        s = s + "200 OK";
        break;
      case 400:
        s = s + "400 Bad Request";
        break;
      case 403:
        s = s + "403 Forbidden";
        break;
      case 404:
        s = s + "404 Not Found";
        break;
      case 500:
        s = s + "500 Internal Server Error";
        break;
      case 501:
        s = s + "501 Not Implemented";
        break;
    }

    s = s + "\r\n"; 
    s = s + "Connection: close\r\n"; 
    s = s + "Server: SimpleHTTPtutorial v0\r\n"; 

    switch (file_type)
    {
       case 0:
        break;
      case 1:
        s = s + "Content-Type: image/jpg\r\n";
        break;
      case 2:
        s = s + "Content-Type: image/gif\r\n";
        break;
      case 3:
        s = s + "Content-Type: application/x-zip-compressed\r\n";
        break;
      case 4:
    	s = s + "Content-Type: image/x-icon\r\n";
        break;
      case 5:
        s = s + "Content-Type: text/html\r\n";
        break;
	default:
	break;
    }

    s = s + "\r\n"; 
    return s;
  }

} 

import java.io.*;
public class expt2
{
	public static void main(String []args)throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
		System.out.println("enter the number of frames: ");
		int no=Integer.parseInt(br.readLine());
		System.out.println("enter the frame details: ");
		int f[][]=new int[10][10];
		for(int i=0;i<no;i++)
		{
			System.out.println("enter the sequence number: ");
			 f[i][0]=Integer.parseInt(br.readLine());
			System.out.println("Enter the data:");
			 f[i][1]=Integer.parseInt(br.readLine());
		}
		
		for(int i=0;i<no;i++)
		{
			for(int j=0;j<no;j++)
			{
				if(f[i][0]<f[j][0])
				{
					int t1=f[i][0];
					f[i][0]=f[j][0];
					f[j][0]=t1;
					int t2=f[i][1];
					f[i][1]=f[j][1];
					f[j][1]=t2;		
				}
			}
		}
		
		System.out.println("Sorted frame list according to sequence numbers :");		
		System.out.println("Sequence \t Data");
		for(int i=0;i<no;i++)
		{
			System.out.print(f[i][0]+"\t\t");
			System.out.print(f[i][1]);	
			System.out.println();
		}
	}
}

/*OUTPUT:
C:\Users\PC-8\Desktop>javac expt2.java
C:\Users\PC-8\Desktop>java expt2
enter the number of frames:
3
enter the frame details:
enter the sequence number:
3
Enter the data:
789
enter the sequence number:
1
Enter the data:
123
enter the sequence number:
2
Enter the data:
456
Sorted frame list according to sequence numbers :
Sequence         Data
1               123
2               456
3               789
C:\Users\PC-8\Desktop>*/

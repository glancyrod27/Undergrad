package acn;
import java.io.*;
class Queuey
{
	int front=-1;
	int rear=-1;
	int a[];
	
	Queuey(int num)
	{
		a=new int[num];
	}
	void insert(int n)
	{
		if(front!=-1)
		{
		rear++;
		a[rear]=n;
		}
		else
		{
			front++;
			rear++;
			a[rear]=n;
		}
		System.out.println("Value"+n+"Inserted");
	}
	
	int delete()
	{
		System.out.println("Value"+a[front]+"deleted");
		int fr=a[front];
		front++;
		return fr;
	}
	
	boolean isEmpty()
	{
		if(front==(rear+1)&&front!=0)
		return true;
		else
		return false;
	}
}

public class hierarchial
{
	public static void main(String args[])throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the no. of routers in the network:");
		int no=Integer.parseInt(br.readLine());
		Queuey q=new Queuey(no);
		int g[][]=new int[no][no];
		for(int i=0;i<no;i++)
		for(int j=0;j<i;j++)
		{
			System.out.println("Enter 1 if an edge is present between "+(char)(i+65)+" and "+(char)(j+65));
			g[i][j]=Integer.parseInt(br.readLine());
			g[j][i]=g[i][j];
		}
		
		System.out.println("Enter the boundary router of region 2:");
		int b1=Integer.parseInt(br.readLine());
		
		System.out.println("The network looks like:");
                System.out.print("Router:");
                for(int i=0;i<no;i++)
		{
		System.out.print("\t\t"+(char)(i+97));
                }
                System.out.println();
		for(int i=0;i<no;i++)
		{
			System.out.print((char)(i+97)+"\t\t");
			for(int j=0;j<no;j++)
			{
				System.out.print(g[i][j]+"\t\t");
			}
			System.out.println();
		}
		
		int hops[]=new int[no];
		int count=1;
		q.insert(0);
		int fro=0;
		boolean flag1=false;
		while(!q.isEmpty())
		{
			flag1=false;
			fro=q.delete();
			for(int u=0;u<no;u++)
			if(g[fro][u]==1)//edge is present
			{
				boolean flag=false;
				for(int p=0;p<no;p++)
				{
					if(q.a[p]==u)
					{
					flag=true;
					break;
					}
					else
					continue;
				}
				if(flag==false)
				{
					q.insert(u);
					flag1=true;
					hops[u]=count;
				
				}
			}
			if(flag1==true)
			count++;
		}
	System.out.println("Complete Table for Router A:");
	System.out.println("Dest\tNo of Hops");
	for(int i=0;i<no;i++)
	System.out.println(i+"\t"+hops[i]);
	
	System.out.println("Hierarchical Table for Router A with boundary router:"+(char)(b1+65));
	System.out.println("Dest\tNo of Hops");
	for(int i=0;i<=b1;i++)
	System.out.println(i+"\t"+hops[i]);
	
	}
}
import java.io.*;
import java.net.*;
class client
{
        public static void main(String arg[])throws IOException
        {
               Socket sock=new Socket(InetAddress.getLocalHost(),2500);
               String s1="HELLO";
               System.out.println("Sending:"+s1+" ");
               BufferedWriter dataout=new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
               dataout.write(s1,0,s1.length());
               dataout.flush();
               sock.close();
         }
}
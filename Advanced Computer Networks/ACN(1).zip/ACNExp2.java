import java.util.*;
class ACNEXP2
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of frames");
		int n=sc.nextInt();
		int seq[]=new int[n];
		String data[]=new String[n];
		for(int i=0;i<n;i++)
		{
			System.out.print("Enter the sequence number" +" ");
			seq[i]=sc.nextInt();
			
			System.out.print("Enter the data"+" ");
			data[i]=sc.next();
            }
		int temp=0;String temp2="";
		for(int i=0;i<n;i++)
			for(int j=0;j<n-1;j++)
			{
				if(seq[j]>seq[j+1])
				{
					temp=seq[j];
					seq[j]=seq[j+1];
					seq[j+1]=temp;
					temp2=data[j];
					data[j]=data[j+1];
					data[j+1]=temp2;

				}
			}
			System.out.println("Sorted order");
                        System.out.println("seq data");
			for(int i=0;i<n;i++)
			{
				System.out.print(seq[i]+"   "+data[i]);
                                System.out.println("");
			}

		}
}
